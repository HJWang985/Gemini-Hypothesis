import os
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import fsolve
from scipy.constants import G

# Constants
A0 = 1.2e-10  # m/s^2
KPC_TO_M = 3.086e19 # m
M_SUN_TO_KG = 1.989e30 # kg
KM_S_TO_M_S = 1e3

class Galaxy:
    def __init__(self, name, data):
        self.name = name
        self.radius_kpc = data[:, 0]
        self.v_obs_kms = data[:, 1]
        self.v_err_kms = data[:, 2]
        self.v_gas_kms = data[:, 3]
        self.v_disk_kms = data[:, 4]
        self.v_bulge_kms = data[:, 5]

        # Use a fixed stellar mass-to-light ratio for this first analysis
        # Based on Lelli et al. (2016), a value of 0.5 is a reasonable start
        self.upsilon_star = 0.5 

    def calculate_newtonian_acceleration(self):
        v_baryons_kms2 = (
            self.v_gas_kms**2 +
            self.upsilon_star * self.v_disk_kms**2 +
            self.upsilon_star * 1.4 * self.v_bulge_kms**2 # Bulge M/L is ~1.4x disk
        )
        # Ensure non-negative values before sqrt
        v_baryons_kms = np.sqrt(np.maximum(0, v_baryons_kms2))
        
        radius_m = self.radius_kpc * KPC_TO_M
        # Avoid division by zero at the center
        radius_m[radius_m == 0] = 1e-6
        
        a_n = (v_baryons_kms * KM_S_TO_M_S)**2 / radius_m
        return a_n

    def solve_mond_acceleration(self, a_n):
        # The equation a*mu(a/A0) = a_N, with mu(x)=x/sqrt(1+x^2), leads to
        # a quadratic equation in a^2: a^4 - (a_N^2)*a^2 - (a_N^2 * A0^2) = 0.
        # The correct, dimensionally consistent analytical solution is:
        a_n_sq = a_n**2
        A0_sq = A0**2
        
        # Solving the quadratic equation for a^2
        a_sq_mond = (a_n_sq + np.sqrt(a_n_sq**2 + 4 * a_n_sq * A0_sq)) / 2
        
        a_mond = np.sqrt(a_sq_mond)
        return a_mond

    def get_predicted_velocities(self):
        a_n = self.calculate_newtonian_acceleration()
        a_mond = self.solve_mond_acceleration(a_n)
        
        radius_m = self.radius_kpc * KPC_TO_M
        v_pred_ms = np.sqrt(np.maximum(0, a_mond * radius_m))
        v_pred_kms = v_pred_ms / KM_S_TO_M_S
        
        v_newton_ms = np.sqrt(np.maximum(0, a_n * radius_m))
        v_newton_kms = v_newton_ms / KM_S_TO_M_S
        
        return v_pred_kms, v_newton_kms

def load_galaxy_data(filename):
    try:
        data = np.loadtxt(filename)
        # Columns: Rad, Vobs, e_Vobs, Vgas, Vdisk, Vbulge
        return data
    except Exception as e:
        print(f"Could not read {filename}: {e}")
        return None

def plot_rotation_curve(galaxy):
    plt.figure(figsize=(10, 7))
    
    v_pred, v_newton = galaxy.get_predicted_velocities()
    
    # Plot observed data
    plt.errorbar(galaxy.radius_kpc, galaxy.v_obs_kms, yerr=galaxy.v_err_kms, fmt='k.', label='Observed', capsize=3)
    
    # Plot Newtonian prediction (baryons only)
    plt.plot(galaxy.radius_kpc, v_newton, 'b--', label='Newtonian (Baryons Only)')
    
    # Plot our model's prediction
    plt.plot(galaxy.radius_kpc, v_pred, 'r-', label='Gemini/MOND Prediction')

    # Plot individual components
    plt.plot(galaxy.radius_kpc, galaxy.v_gas_kms, 'g:', label='Gas')
    plt.plot(galaxy.radius_kpc, np.sqrt(galaxy.upsilon_star) * galaxy.v_disk_kms, 'y:', label='Disk')
    if np.any(galaxy.v_bulge_kms > 0):
        plt.plot(galaxy.radius_kpc, np.sqrt(galaxy.upsilon_star * 1.4) * galaxy.v_bulge_kms, 'm:', label='Bulge')

    plt.title(f'Rotation Curve for {galaxy.name}')
    plt.xlabel('Radius (kpc)')
    plt.ylabel('Velocity (km/s)')
    plt.legend()
    plt.grid(True, linestyle='--', alpha=0.6)
    
    # Save the figure
    output_dir = 'rotation_curve_plots'
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    plt.savefig(os.path.join(output_dir, f'{galaxy.name}_rotation_curve.png'))
    plt.close()

def main():
    data_dir = 'SPARC_data'
    galaxy_files = [f for f in os.listdir(data_dir) if f.endswith('.dat')]
    
    # Let's test with a few interesting galaxies first
    # UGC00128 is a classic LSB galaxy
    # NGC7814 is a bulge-dominated HSB galaxy
    test_galaxies = ['UGC00128_rotmod.dat', 'NGC7814_rotmod.dat', 'F568-3_rotmod.dat']

    for fname in test_galaxies:
        if fname in galaxy_files:
            galaxy_name = fname.replace('.dat', '')
            print(f"Processing {galaxy_name}...")
            filepath = os.path.join(data_dir, fname)
            raw_data = load_galaxy_data(filepath)
            
            if raw_data is not None:
                galaxy = Galaxy(galaxy_name, raw_data)
                plot_rotation_curve(galaxy)
                print(f"Plot saved for {galaxy_name}.")

if __name__ == '__main__':
    main() 