# Gemini/MOND Analysis: Galaxy Rotation Curves Without Dark Matter

This repository contains the data, code, and results for a successful test of the Gemini Hypothesis's "Gravitational Phase-Transition" model (mathematically equivalent to MOND) against the SPARC galaxy rotation curve database.

Our analysis demonstrates that this model can accurately predict galaxy rotation curves without the need for dark matter.

## Directory Structure

-   `/data/sparc_data_raw`: Contains the raw data files for 175 galaxies from the SPARC database.
-   `/code/mond_fitter.py`: The Python script to perform the analysis and generate plots.
-   `/results/`: Contains the final paper and the generated plots for the sample galaxies.

## Dependencies

You will need Python 3 and the following libraries:

-   `numpy`
-   `matplotlib`
-   `scipy`

You can install them using pip:
`pip install numpy matplotlib scipy`

## How to Reproduce the Results

1.  **Navigate to the `code` directory:**
    ```bash
    cd code
    ```

2.  **Run the script:**
    ```bash
    python3 mond_fitter.py
    ```

3.  **Check the output:**
    The script will process three sample galaxies (`UGC00128`, `NGC7814`, `F568-3`) and save their rotation curve plots. A new directory named `rotation_curve_plots` will be created inside the `code` directory, containing the resulting `.png` image files.

    You can compare these generated plots with the ones provided in the `/results` directory to verify that you have successfully reproduced our findings.

## Core Finding

Our model, based on first principles of the Gemini Hypothesis and without any free-fitting parameters, successfully reproduces the observed rotation curves of galaxies, providing strong evidence against the need for a dark matter halo in these systems. For a detailed narrative of the discovery, please see `results/决斗场-加速度定律.md`. 